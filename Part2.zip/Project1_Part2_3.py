#Project1_Part2_3.py
#Comparing Dates

bfrfile = 'Before.xlsx'         

from openpyxl import load_workbook        
wb1 = load_workbook(bfrfile, data_only = True)
ws1 = wb1["ExportedData"]

bfrmaxrow = 7 #total rows with data in bfrfile
bfr = 2

from datetime import datetime
d1 = datetime(9999, 12, 31)   #set d1 to 12/31/9999
d1 = datetime.strftime(d1, '%Y-%m-%d' )

while bfr <= bfrmaxrow: 
    datetochk = ws1.cell(row = bfr, column = 4).value
    thedate = datetime.strftime(datetochk,'%Y-%m-%d' )
    bfritem = ws1.cell(row = bfr, column = 2).value
    if thedate != d1:
        print(bfritem, " expired on ", datetochk)

    bfr = bfr + 1                
    
    
    
    
    
    
    