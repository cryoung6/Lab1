#LookupColData.py
def lcd(item, wb, ws, matchcolnum, lkupcolnum):

	startrow = 2
	while startrow <= ws.max_row: 
		if ws.cell(row = startrow, column = matchcolnum).value == item:
			return ws.cell(row = startrow, column = lkupcolnum).value
			startrow = ws.max_row + 1 
		else:
			startrow = startrow + 1
	return "nothing found"
