def fh(ws, str1, str2, str3, colwidth):
    
    from openpyxl.styles import Font
    
    ft = Font(color='4F81BD', bold = True)
    ws['A1'].font = ft
    ws['B1'].font = ft
    ws['C1'].font = ft

    ws.cell(row = 1, column = 1).value = str1
    ws.cell(row = 1, column = 2).value = str2
    ws.cell(row = 1, column = 3).value = str3    
          
    ws.column_dimensions['A'].width = 12
    ws.column_dimensions['B'].width = colwidth
    ws.column_dimensions['C'].width = colwidth
  
    for row in ws.iter_rows():
        for cell in row:
            cell.alignment = cell.alignment.copy(wrapText=True)
            
            