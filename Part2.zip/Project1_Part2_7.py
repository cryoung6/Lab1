#Project1_Part2_7.py
#Find a substring in a string

bfrfile = 'Before.xlsx'         #1

from openpyxl import load_workbook          #open excel file bfrfile
wb1 = load_workbook(bfrfile, data_only = True)
ws1 = wb1["ExportedData"]

bfrmaxrow = 7 #total rows with data in bfrfile
bfr = 2


while bfr <= bfrmaxrow: 
    foundit1 = -1
    bfritem = ws1.cell(row = bfr, column = 2)
    str = "New"
    strbfritem = bfritem.value
    foundit1 = strbfritem.find(str) #finds str in strbfritem and returns the location
    if foundit1 > -1:
            print("found str in strbfritem")        
           
    bfr = bfr + 1    #move to next row in bfrfile













