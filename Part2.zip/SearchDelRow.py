def sdr(filename, strsearch, searchcolumn):
    "this function deletes rows in file that have the search string"

    import re
    
    from openpyxl import load_workbook       
    wb = load_workbook(filename)
    ws = wb["Sheet1"]

    r =2
    
    while r <= ws.max_row:
        
        strthiscell = ws.cell(row = r, column = searchcolumn).value

        if re.search (strsearch, strthiscell):
            ws.delete_rows(r, 1)
            
        r = r + 1

    wb.save(filename)