def ifexistsdelete(filename):
    import os

    if os.path.exists(filename):
        os.remove(filename)


