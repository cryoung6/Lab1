#Project1.1.py
print("Welcome to Project1.1.py")

bfrfile = 'Before.xlsx'         #1
aftfile = 'After.xlsx'          #2
rnfile =  'Research_Notes.xlsx' #3 this file will be used in Part 2
diffile = 'Diff.xlsx'           #4


from openpyxl import load_workbook          #open excel file bfrfile
wb1 = load_workbook(bfrfile, data_only = True)
ws1 = wb1["ExportedData"]

from openpyxl import load_workbook          #open excel file aftfile
wb2 = load_workbook(aftfile, data_only = True)
ws2 = wb2["ExportedData"]

from openpyxl import Workbook 
wb4 = Workbook()
ws4 = wb4.create_sheet("Diff")


bfrmaxrow = 6 #total rows with data in bfrfile
bfr = 2
dif = 2
aftmaxrow = 6 #total rows with data in aftfile

while bfr <= bfrmaxrow: 
    bfritem = ws1.cell(row = bfr, column = 2)
    aft = 2 
    itemretired = 1
 
    while aft <= aftmaxrow: 
        aftitem = ws2.cell(row = aft, column = 2)
        if bfritem.value == aftitem.value: 
            itemretired = 0
            if ws1.cell(bfr, 3).value == ws2.cell(aft, 3).value:
                aft = aftmaxrow + 1 
            else:
                ws4.cell(dif, 1).value = bfritem.value 
                ws4.cell(dif, 2).value = ws1.cell(bfr, 3).value
                ws4.cell(dif, 3).value = ws2.cell(aft, 3).value 
                dif = dif + 1
                aft = aftmaxrow + 1 
        else:
            aft = aft + 1 #move to next row in aftfile
           
    bfr = bfr + 1    #move to next row in bfrfile

wb4.save(diffile)













